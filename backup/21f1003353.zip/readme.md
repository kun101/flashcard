# Local Setup
- Clone the project
- Run `pip install -r requirements.txt` to install all dependencies

# Local Development Run
- `python app.py` It will start the flask app in `development`. Suited for local development. 

# Replit run
- Go to shell and run
    `pip install --upgrade poetry`
- Click on `main.py` and click button run
- The web app will be availabe at https://appName.userName.repl.co
- Format https://<replname>.<username>.repl.co

# Folder Structure

- `database.db` is the sqlite DB. It can be anywhere on the machine. Adjust the path in `app.py`. This app ships with one required for testing.
- `/` is where our application code is
- `static` - default `static` files folder. It serves at '/static' path.
- `templates` - Default flask templates folder


```
Flashcard/
├── app.py
├── database.db
├── database.sqlite3
├── readme.md
├── requirements.txt
├── static/
│   └── logo.svg
├── templates/
│   ├── add_card.html
│   ├── add_deck.html
│   ├── create_user.html
│   ├── dashboard.html
│   ├── edit_card.html
│   ├── edit_deck.html
│   ├── login.html
│   └── review_deck.html
└── 
```