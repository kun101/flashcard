var deckListComponent = Vue.component('deck-list', {
    template: `<div class="card">
                <div class="card-body">
                    <h3 class="card-title">All Decks</h3>
                    <ul class="list-group list-group-flush">
                        <p v-if="decks.length==0">No Decks Available. Add a Deck to Continue</p>
                        <li v-for="deck in decks" class="list-group-item mt-1 mb-2 ps-0">
                            <div class="row">
                                <div class="col">
                                    <h5>%{ deck.deck_name }</h5>
                                </div>
                                <div class="col">
                                    <div class="btn-group float-end" role="group" aria-label="Basic example">
                                        <router-link to="/">Home</router-link>
                                        <a type="button" class="btn btn-success"
                                        :href="'/add/deck/' + deck.deck_id"><i
                                                class="bi bi-play-fill"></i></a>
                                        <a type="button" class="btn btn-warning"
                                            :href="'/edit/deck/' + deck.deck_id"><i
                                                class="bi bi-pencil-fill"></i></a>
                                        <a type="button" class="btn btn-danger"
                                            :href="'/delete/deck/' + deck.deck_id"><i
                                                class="bi bi-trash-fill"></i></a>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="card-footer">
                    <a href="/add/deck" class="btn btn-primary">Add Deck</a>
                </div>
            </div>`,
    data: function () {
        return {
            decks: [],
        }
    },
    delimiters: ['%{', '}'],
    mounted: async function () {
        // fetch decks from server
        var response = await fetch('/api/decks', {
            method: 'GET'
        });
        var data = await response.json();
        this.decks = data["decks"];
    },
});

var editDeckComponent = Vue.component('edit-deck', {
    template: `<div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-xl-10">
                    <div class="card rounded-3 text-black">
                        <div class="row g-0">
                            <div class="col-lg-12 d-flex align-items-center" style="background: #0d6efd;">
                                <div class="text-white px-3 py-4 p-md-5 mx-md-4">
                                    <h4 class="mb-4">Edit %{ deck.deck_name }
                                    </h4>
                                    <a href="/dashboard" class="btn btn-outline-light">Go Back</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="card-body p-md-5 mx-md-4">
                                <form action="'/edit/deck/' + deck.deck_id" method="POST">
                                    <div class="row">
                                        <input type="text" class="form-control" name="deck_name"
                                            :value="deck.deck_name" required>
                                        <button type="submit" class="btn btn-primary mt-3">Change Deck Name</button>
                                    </div>
                                </form>
                                <br><br>
                                <h2>All Cards in %{ deck.deck_name }%&nbsp;&nbsp;<span><a type="button"
                                            class="btn btn-primary" :href="'/add/deck/' + deck.deck_id + '/add/card/'">Add
                                            Card</a></span></h2>
                                <br><br>
                                <ul class="list-group list-group mb-5">
                                    <li v-for="card in cards" class="list-group-item">
                                        <div class="col float-start"><span
                                                class="align-items-centre"><b>%{ card.question }}</b><br>%{ card.answer }</span>
                                        </div>
                                        <div class="col float-end">
                                            <div class="btn-group float-end" role="group" aria-label="Basic example">
                                                <a type="button" class="btn btn-warning"
                                                    :href="'/edit/deck/' + deck.deck_id + '/card/' + card.card_id">Edit</a>
                                                <a type="button" class="btn btn-danger"
                                                    :href="'/delete/deck/' + deck.deck_id + '/card/' + card.card_id">Remove</a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>`,
    data : function () {
        return {
            deck: {},
            cards: []
        }
    },
    delimiters: ['%{', '}'],
    mounted: async function () {
        var id = window.location.pathname.split("deck/")[1]
        var response = await fetch('/api/deck/' + id, {
            method: 'GET'
        });
        var data = await response.json();
        this.deck = data["deck"];
        this.cards = data["cards"];
    }
});

var app = new Vue({
    el: '#app',
});